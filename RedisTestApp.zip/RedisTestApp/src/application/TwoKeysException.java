package application;

@SuppressWarnings("serial")
public class TwoKeysException extends Exception {
	TwoKeysException(){
	super();}
}
