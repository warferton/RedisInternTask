package application;

@SuppressWarnings("serial")
public class NoDataException extends Exception {
	NoDataException(){
		super();
	}

}
